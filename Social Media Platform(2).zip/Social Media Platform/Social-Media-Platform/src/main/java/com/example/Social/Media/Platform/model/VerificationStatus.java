package com.example.Social.Media.Platform.model;

public enum VerificationStatus {
    PENDING,
    VERIFIED
}
